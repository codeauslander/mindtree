package Class;

public class Playground {

	public static void main(String[] args) {
//		String a = new String("a");
//		String A = new String("a");
//		System.out.println(a == A);
//		boolean[] list = new boolean[2];
//		for (int i = 0; i < list.length; i++) {
//			System.out.println(list[i]);
//		}
	}

}
