package Jan19_Basecamp_HackerEarth;

public class SagarsLearning{
  
  public static int lowerCommomMultiplicator(int number){
    return 0;
  }
  public static int higtherCommomFactor(int number){
    return 0;
  }
  public static void main(String[] args) {
    
  }
  public static void testHardCode(){
    System.out.println("Sagar's Learning");
    int number = 10;
    int resultLowerCommomMultiplicator = lowerCommomMultiplicator(number);
    int resultHigtherCommomFactor = higtherCommomFactor(number);
    System.out.println("resultLowerCommomMultiplicator: " + resultLowerCommomMultiplicator);
    System.out.println();
    System.out.println("resultHigtherCommomFactor: " + resultHigtherCommomFactor);
    System.out.println();
  }

}