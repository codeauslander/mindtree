package Jan19_Pre_Orchard_Challenge;

import java.util.Scanner;

public class ScannerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("start");
		Scanner userInput = new Scanner(System.in);
		System.out.println("value1");
		String value = userInput.nextLine();
		System.out.println("value1 is: " + value.length());
		System.out.println("value2");
		String value2 = userInput.nextLine();
		System.out.println("value2 is: " + value2.length());
//		System.out.println(value);
		

	}

}
