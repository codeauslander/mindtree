package ShotClass;
import java.util.HashMap;
import java.util.List;
public class C4_Keypad {
	public static int countMessages(List<String> keys, String message) {
		// Write your code here
		char[] characters = message.toCharArray();
		for (int index = 0; index < characters.length; index++) {
			
		}
		return (2/9) * message.length();
	} 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
